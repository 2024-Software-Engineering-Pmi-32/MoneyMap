﻿using Npgsql;
using System;

class Program
{
    static void Main(string[] args)
    {

        DatabaseManager dbManager = new DatabaseManager();

        dbManager.GetAllData();

        //dbManager.InsertTestData();

        Console.ReadLine();
    }
}

class DatabaseManager
{
    private string connectionString = "Host=localhost;Username=postgres;Password=007;Database=Money map";

    public void GetAllData()
    {
        try
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                Console.WriteLine("Connection to DB is successful");

                Console.WriteLine("\nUsers:");
                string query = "SELECT * FROM Users";
                using (var command = new NpgsqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["UserId"]}, Username: {reader["Username"]}, Email: {reader["Email"]}");
                    }
                }
                Console.WriteLine("\nIncomes:");
                string queryIncomes = "SELECT * FROM Incomes";
                using (var commandIncomes = new NpgsqlCommand(queryIncomes, connection))
                using (var readerIncomes = commandIncomes.ExecuteReader())
                {
                    while (readerIncomes.Read())
                    {
                        Console.WriteLine($"ID: {readerIncomes["IncomeId"]}, UserID: {readerIncomes["UserId"]}, Amount: {readerIncomes["Amount"]}, Source: {readerIncomes["Source"]}, DateReceived: {readerIncomes["DateReceived"]}");
                    }
                }

               
                Console.WriteLine("\nExpenses:");
                string queryExpenses = "SELECT * FROM Expenses";
                using (var commandExpenses = new NpgsqlCommand(queryExpenses, connection))
                using (var readerExpenses = commandExpenses.ExecuteReader())
                {
                    while (readerExpenses.Read())
                    {
                        Console.WriteLine($"ID: {readerExpenses["ExpenseId"]}, UserID: {readerExpenses["UserId"]}, Amount: {readerExpenses["Amount"]}, Category: {readerExpenses["Category"]}, DateSpent: {readerExpenses["DateSpent"]}");
                    }
                }
            }
        }
        catch (NpgsqlException ex)
        {
            Console.WriteLine($"Error connecting to PostgreSQL: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
        finally
        {
            Console.WriteLine("Connection succesfully ended");
        }
    }

    public void InsertTestData()
    {
        try
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                Console.WriteLine("The connection to the database for inserting test data is successful.");
                Random rnd = new Random();

                for (int i = 1; i <= 30; i++) 
                {
                    string insertUserQuery = "INSERT INTO Users (Username, PasswordHash, Email, DateRegistered) " +
                                             "VALUES (@username, @passwordHash, @email, @dateRegistered)";
                    using (var command = new NpgsqlCommand(insertUserQuery, connection))
                    {
                        command.Parameters.AddWithValue("@username", $"user{i}");
                        command.Parameters.AddWithValue("@passwordHash", $"passwordHash{i}");
                        command.Parameters.AddWithValue("@email", $"user{i}@example.com");
                        command.Parameters.AddWithValue("@dateRegistered", DateTime.Now.AddDays(-i));

                        command.ExecuteNonQuery();
                    }
                }

                for (int i = 0; i < 30; i++)
                {
                    string incomeQuery = "INSERT INTO Incomes (UserId, Amount, Source, DateReceived) VALUES (@UserId, @Amount, @Source, @DateReceived)";
                    using (var command = new NpgsqlCommand(incomeQuery, connection))
                    {
                        command.Parameters.AddWithValue("UserId", rnd.Next(1, 31)); 
                        command.Parameters.AddWithValue("Amount", rnd.Next(100, 1000));
                        command.Parameters.AddWithValue("Source", "Salary");
                        command.Parameters.AddWithValue("DateReceived", DateTime.Now);

                        command.ExecuteNonQuery();
                    }
                }

                
                for (int i = 0; i < 30; i++)
                {
                    string expenseQuery = "INSERT INTO Expenses (UserId, Amount, Category, DateSpent) VALUES (@UserId, @Amount, @Category, @DateSpent)";
                    using (var command = new NpgsqlCommand(expenseQuery, connection))
                    {
                        command.Parameters.AddWithValue("UserId", rnd.Next(1, 31)); 
                        command.Parameters.AddWithValue("Amount", rnd.Next(50, 500));
                        command.Parameters.AddWithValue("Category", "Food");
                        command.Parameters.AddWithValue("DateSpent", DateTime.Now);

                        command.ExecuteNonQuery();
                    }
                }
                Console.WriteLine("Test data successfully added to the database");
            }
        }
        catch (NpgsqlException ex)
        {
            Console.WriteLine($"Error connecting to PostgreSQL: {ex.Message}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
        finally
        {
            Console.WriteLine("The data insertion process is complete");
        }
    }
}
